﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace View
{
    /// <summary>
    /// creating a client and 
    /// creating a thread of sending and
    /// reciving msg
    /// to and from the server
    /// </summary>
    class Program
    {
      
    }
}
